// const auth = () =>{
//   window.oauth2.start();
// }

// document.getElementById('authButton').addEventListener('click',auth);



 // Client ID and API key from the Developer Console
 var CLIENT_ID = '19686602327-9r18u3m3mvpt9195nafk1fjde8cc6vjh.apps.googleusercontent.com';
 var API_KEY = 'AIzaSyDhLKHKTBWjlDSrRLPY_-kvgV0xcJH7qd0';
 let accessToken;
//   var CLIENT_ID = '559403438872-5dgch6vvib2ckptf7ggn220n5a2l5935.apps.googleusercontent.com';
//   var API_KEY = 'AIzaSyAWF7RpGr723giH67mQ63IorWOnCfSQbzM';

 // Array of API discovery doc URLs for APIs used by the quickstart
 var DISCOVERY_DOCS = ["https://www.googleapis.com/discovery/v1/apis/drive/v3/rest"];

 // Authorization scopes required by the API; multiple scopes can be
 // included, separated by spaces.
 var SCOPES = 'https://www.googleapis.com/auth/drive';

 var authorizeButton = document.getElementById('authorize_button');
 var signoutButton = document.getElementById('signout_button');

 /**
  *  On load, called to load the auth2 library and API client library.
  */
 function handleClientLoad() {
   console.log("Entrooo!")
   gapi.load('client:auth2', initClient);
 }

 /**
  *  Initializes the API client library and sets up sign-in state
  *  listeners.
  */
 function initClient() {
   gapi.client.init({
     apiKey: API_KEY,
     clientId: CLIENT_ID,
     discoveryDocs: DISCOVERY_DOCS,
     scope: SCOPES
   }).then(function () {
     // Listen for sign-in state changes.
     console.log("coll",gapi.auth2.getAuthInstance().isSignedIn);
     gapi.auth2.getAuthInstance().isSignedIn.listen(updateSigninStatus);

     // Handle the initial sign-in state.
     updateSigninStatus(gapi.auth2.getAuthInstance().isSignedIn.get());
     authorizeButton.onclick = handleAuthClick;
     signoutButton.onclick = handleSignoutClick;
   }, function(error) {
     appendPre(JSON.stringify(error, null, 2));
   });
 }

 /**
  *  Called when the signed in status changes, to update the UI
  *  appropriately. After a sign-in, the API is called.
  */
 function updateSigninStatus(isSignedIn) {
   console.log("Change signin status",isSignedIn)
   if (isSignedIn) {
     authorizeButton.style.display = 'none';
     signoutButton.style.display = 'block';
     listFiles();
   } else {
     authorizeButton.style.display = 'block';
     signoutButton.style.display = 'none';
   }
 }

 /**
  *  Sign in the user upon button click.
  */
 function handleAuthClick(event) {
   console.log("Handle signin")
   gapi.auth2.getAuthInstance().signIn();
 }

 /**
  *  Sign out the user upon button click.
  */
 function handleSignoutClick(event) {
   gapi.auth2.getAuthInstance().signOut();
 }

 /**
  * Append a pre element to the body containing the given message
  * as its text node. Used to display the results of the API call.
  *
  * @param {string} message Text to be placed in pre element.
  */
 function appendPre(message) {
   var pre = document.getElementById('content');
   var textContent = document.createTextNode(message + '\n');
   pre.appendChild(textContent);
 }

 /**
  * Print files.
  */
  async function listFiles  () {
   retrieveAllFiles(displayItems);        
 }

function displayItems (result) {
   console.log("response",result)
   appendPre('Files:');
   if (result && result.length > 0) {
       for (var i = 0; i<result.length; i++) {
           var file = result[i];
           appendPre(file.name + ' (' + file.id + ')');
       }
   } else {
   appendPre('No files found.');
   }
}

function retrieveAllFiles(callback) {
   var initialRequest = gapi.client.drive.files.list({});
   initialRequest.execute((resp)=>{
       console.log("resp",resp.files,resp['files']);
       displayItems(resp.files);
   })
   
}

document.getElementById("uploadfile").addEventListener("change", run);

function run(obj) {
const file = obj.target.files[0];
if (file.name != "") {
 let fr = new FileReader();
 fr.fileName = file.name;
 fr.fileSize = file.size;
 fr.fileType = file.type;
 fr.readAsArrayBuffer(file);
 fr.onload = resumableUpload;
}
}

function resumableUpload(e) {
accessToken = gapi.auth.getToken().access_token; // Please set access token here.
console.log("accessToken",accessToken)
document.getElementById("progress").innerHTML = "Initializing.";
const f = e.target;
const resource = {
 fileName: f.fileName,
 fileSize: f.fileSize,
 fileType: f.fileType,
 fileBuffer: f.result,
 accessToken: accessToken,
};
const ru = new ResumableUploadToGoogleDrive();
ru.Do(resource, function (res, err) {
 if (err) {
   console.log(err);
   return;
 }
 console.log(res);
 let msg = "";
 if (res.status == "Uploading") {
   msg =
     Math.round(
       (res.progressNumber.current / res.progressNumber.end) * 100
     ) + "%";
 } else {
   msg = res.status;
 }
 document.getElementById("progress").innerText = msg;
});
}